package com.dicoding.githubuserappnavigationandapi.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.dicoding.githubuserappnavigationandapi.GlideApp
import com.dicoding.githubuserappnavigationandapi.R
import com.dicoding.githubuserappnavigationandapi.adapter.SectionsPagerAdapter
import com.dicoding.githubuserappnavigationandapi.databinding.ActivityDetailUserBinding
import com.dicoding.githubuserappnavigationandapi.response.UserItem
import com.google.android.material.tabs.TabLayoutMediator
import jp.wasabeef.glide.transformations.CropCircleWithBorderTransformation

class DetailUser : AppCompatActivity() {
    private var _binding: ActivityDetailUserBinding? = null
    private val binding get() = _binding!!

    private val sectionsPagerAdapter by lazy { SectionsPagerAdapter(this@DetailUser) }
    private lateinit var detailViewModel: DetailViewModel
    private lateinit var query: String
    private var countdown: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        val from = intent.getStringExtra(TAG)
        if (from == "Follow") {
            setTheme(R.style.AnimStyleVertical)
        }
        super.onCreate(savedInstanceState)

        _binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val data = intent.getParcelableExtra<UserItem>(EXTRA_USER)

        data?.login?.let {
            query = it
            getDetail(it)
        }
    }

    private fun getDetail(username: String) {
        val detailViewModel: DetailViewModel by viewModels { DetailViewModelFactory(username) }
        this.detailViewModel = detailViewModel

        detailViewModel.isLoading.observe(this@DetailUser) {
            showLoading(it)
        }

        detailViewModel.detailUser.observe(this@DetailUser) { detailUser ->

            val color = ContextCompat.getColor(this, R.color.github_orange)

            val circularProgressDrawable = CircularProgressDrawable(this)
            circularProgressDrawable.setColorSchemeColors(color)
            circularProgressDrawable.strokeWidth = 5f
            circularProgressDrawable.centerRadius = 15f
            circularProgressDrawable.start()

            GlideApp
                .with(this)
                .load(detailUser?.avatarUrl)
                .placeholder(circularProgressDrawable)
                .transform(CropCircleWithBorderTransformation(7, color))
                .into(binding.detailProfileImage)

            binding.apply {
                if (detailUser?.name != null) {
                    detailUsersName.text = detailUser.name
                }
                else {
                    detailUsersName.visibility = View.GONE
                }

                val stringUsername = "@${detailUser?.login}"
                val title = "${detailUser?.login}\'s Detail"
                setTitle(title)
                detailUsername.text = stringUsername

                val textFollowers = "Followers\n${detailUser?.followers}"
                val textFollowing = "Following\n${detailUser?.following}"
                followers.text = textFollowers
                following.text = textFollowing

                if (detailUser?.location != null) {
                    location.text = detailUser.location
                }
                else {
                    pin.visibility = View.GONE
                    location.visibility = View.GONE
                }

                if (detailUser?.company != null) {
                    company.text = detailUser.company
                }
                else {
                    building.visibility = View.GONE
                    company.visibility = View.GONE
                }

                nRepo.text = detailUser?.publicRepos.toString()

                detailUser?.let {
                    sectionsPagerAdapter.user = it
                    binding.viewPager.adapter = sectionsPagerAdapter
                }

                TabLayoutMediator(binding.tabs, binding.viewPager) { tab, position ->
                    tab.text = resources.getString(TAB_TITLES[position])
                }.attach()
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.apply {
                progressBar.visibility = View.VISIBLE
                detailGroup.visibility = View.GONE
            }
            startTimer(true)

        } else {
            binding.apply {
                progressBar.visibility = View.GONE
                detailGroup.visibility = View.VISIBLE
                error.visibility = View.GONE
            }
            startTimer(false)
        }
    }

    private fun startTimer(start: Boolean) {
        countdown?.cancel()
        if (start) {
            countdown = object : CountDownTimer(19000, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    if (millisUntilFinished < 10000) {
                        binding.error.visibility = View.VISIBLE
                        val text =
                            "Long loading time,\nwaiting for " + millisUntilFinished / 1000 + " second"
                        binding.error.text = text
                    }
                }

                override fun onFinish() {
                    binding.error.visibility = View.VISIBLE
                    val text = "Data cannot be loaded,\ntap to retry"
                    binding.error.text = text
                    binding.retry.visibility = View.VISIBLE
                    setListenerRetry()
                    cancel()
                }
            }.start()
        }
        else {
            countdown?.cancel()
        }
    }

    private fun setListenerRetry() {
        binding.retry.setOnClickListener {
            detailViewModel.detailUser(query)
            binding.error.visibility = View.GONE
            binding.retry.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    companion object {
        const val EXTRA_USER = "extra_user"
        const val TAG = "from"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.fragment_followers,
            R.string.fragment_following
        )
    }
}