package com.dicoding.githubuserappnavigationandapi.ui.main

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.SearchView
import androidx.activity.viewModels
import androidx.core.content.getSystemService
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubuserappnavigationandapi.ui.detail.DetailUser
import com.dicoding.githubuserappnavigationandapi.adapter.MainActivityAdapter
import com.dicoding.githubuserappnavigationandapi.databinding.ActivityMainBinding
import com.dicoding.githubuserappnavigationandapi.response.UserItem

class MainActivity : AppCompatActivity() {
    private var _binding: ActivityMainBinding? = null
    private val binding get() = _binding!!
    private val mainViewModel by viewModels<MainViewModel>()
    private val mainAdapter by lazy { MainActivityAdapter(listUser) }

    private lateinit var search: String
    private var listUser = ArrayList<UserItem>(0)

    private var countdown: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mainLayoutManager = LinearLayoutManager(this@MainActivity)
        val itemDecoration = DividerItemDecoration(this@MainActivity, mainLayoutManager.orientation)

        binding.rvUser.apply {
            adapter = mainAdapter
            setHasFixedSize(true)
            layoutManager = mainLayoutManager
            addItemDecoration(itemDecoration)
        }

        setListener()
        populateView()

        mainViewModel.isLoading.observe(this@MainActivity) {
            showLoading(it)
        }

        binding.search.setOnFocusChangeListener{view, b ->
            if (!b) {
                currentFocus?.clearFocus()
                view.clearFocus()
                val imm = getSystemService<InputMethodManager>()
                imm?.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun setListener() {
        val queryTextListener = object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    search = query
                    mainViewModel.getUser(search)
                    listUser.clear()
                    mainAdapter.notifyDataSetChanged()
                }
                return true
            }
            override fun onQueryTextChange(query: String?): Boolean {
                if (query != null) {
                    search = query
                }
                return true
            }
        }

        binding.search.setOnQueryTextListener(queryTextListener)
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun populateView() {
        mainViewModel.listUser.observe(this@MainActivity) { userList ->
            listUser.clear()
            listUser.addAll(userList)
            mainAdapter.notifyDataSetChanged()
            setOnClickData()
        }

        mainViewModel.searchUser.observe(this@MainActivity) { userList ->
            if (userList != null) {
                listUser.clear()
                listUser.addAll(userList)
                mainAdapter.notifyDataSetChanged()
                setOnClickData()
            }
        }
    }

    private fun setOnClickData() {
        mainAdapter.setOnItemClickCallback(object : MainActivityAdapter.OnItemClickCallback {
            override fun onItemClicked(user: UserItem) {
                val intent = Intent(this@MainActivity, DetailUser::class.java)
                intent.putExtra(DetailUser.EXTRA_USER, user)
                intent.putExtra(DetailUser.TAG, "main")
                startActivity(intent)
            }
        })
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
            startTimer(true)

        } else {
            binding.error.visibility = View.GONE
            binding.progressBar.visibility = View.GONE
            startTimer(false)
        }
    }

    private fun startTimer(start: Boolean) {
        countdown?.cancel()
        if (start) {
            countdown = object : CountDownTimer(19000, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    if (millisUntilFinished < 10000) {
                        binding.error.visibility = View.VISIBLE
                        val text =
                            "Long loading time,\nwaiting for " + millisUntilFinished / 1000 + " second"
                        binding.error.text = text
                    }
                }

                override fun onFinish() {
                    binding.error.visibility = View.VISIBLE
                    val text = "Data cannot be loaded,\ntap to retry"
                    binding.error.text = text
                    binding.retry.visibility = View.VISIBLE
                    val query = mainViewModel.lastTry.value.toString()
                    setListenerRetry(query)
                    cancel()
                }
            }.start()
        }
        else {
            countdown?.cancel()
        }
    }

    private fun setListenerRetry(query: String) {
        binding.retry.setOnClickListener {
            when (query) {
                "load_user" -> {
                    mainViewModel.loadUser()
                    binding.error.visibility = View.GONE
                    binding.retry.visibility = View.GONE
                }
                "get_user" -> {
                    mainViewModel.getUser(search)
                    binding.error.visibility = View.GONE
                    binding.retry.visibility = View.GONE
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}