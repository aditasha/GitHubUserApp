package com.dicoding.githubuserappnavigationandapi.ui.main

import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.githubuserappnavigationandapi.api.ApiConfig
import com.dicoding.githubuserappnavigationandapi.response.SearchResponse
import com.dicoding.githubuserappnavigationandapi.response.UserItem
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel : ViewModel() {
    private val _listUser = MutableLiveData<ArrayList<UserItem>>()
    val listUser: LiveData<ArrayList<UserItem>> = _listUser

    private val _searchUser = MutableLiveData<ArrayList<UserItem>>()
    val searchUser: LiveData<ArrayList<UserItem>> = _searchUser

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _lastTry = MutableLiveData<String>()
    val lastTry: LiveData<String> = _lastTry

    init {
        loadUser()
    }

    fun loadUser() {
        _isLoading.value = true
        val client = ApiConfig.getApiService().loadUser()
        client.enqueue(object : Callback<ArrayList<UserItem>> {
            override fun onResponse(
                call: Call<ArrayList<UserItem>>,
                response: Response<ArrayList<UserItem>>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _listUser.postValue(response.body())
                } else {
                    Log.e(TAG, "onResponseFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<ArrayList<UserItem>>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message.toString()}")
                _lastTry.postValue("load_user")
            }
        })
    }

    fun getUser(user_id: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().searchUser(user_id)
        client.enqueue(object : Callback<SearchResponse> {
            override fun onResponse(
                call: Call<SearchResponse>,
                response: Response<SearchResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _searchUser.postValue(response.body()?.items)
                } else {
                    Log.e(TAG, "onResponseFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<SearchResponse>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message.toString()}")
                _lastTry.postValue("get_user")
            }
        })
    }
}